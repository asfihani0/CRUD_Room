package com.example.crud_room.room

class Constant {
    companion object {
        const val TYPE_READ = 0
        const val TYPE_CREATE = 1
        const val TYPE_UPDATE = 2
    }
}